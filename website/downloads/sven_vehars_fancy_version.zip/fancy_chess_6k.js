// ***************************
// 6k chess
// custom functions go here
// ***************************

function about() {
	if(document.getElementById('tableAbout').style.display == 'block') {
		document.getElementById('tableAbout').style.display = 'none';
	}else{
		document.getElementById('tableAbout').style.display = 'block';
	}
};
